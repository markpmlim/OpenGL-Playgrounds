// How to load and render a wavefront (.obj) using SceneKit's ModelIO.
// This demo does not import any materials declared in an associated
// .mtl file.

import XCPlayground

// Create instance of ViewController and ...
let vc = SPViewController()
// ... tell playground to show it in live view
XCPlaygroundPage.currentPage.liveView = vc
