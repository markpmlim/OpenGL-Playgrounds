/*
 How to load a wavefront (.obj) using SceneKit's ModelIO.
 This demo does not import any materials declared in an associated
 .mtl file.
 Renders a 3-colored cube. The opposite faces of the cube
 are of the same color.
 */

import Cocoa
import XCPlayground

// Create instance of ViewController and ...
let vc = SPViewController()
// ... tell playground to show it in live view
XCPlaygroundPage.currentPage.liveView = vc
