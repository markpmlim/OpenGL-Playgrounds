// The method MDLAsset can load the sub-classes of MDLObject like
// MDLMesh, MDLLight and MDLCamera.
//
// A model can have more than 1 instance of MDLObject.
// A model can have more than 1 instance of MDLMesh.
// Each instance of MDLMesh has an array of MDLSubmesh.
// In other words, more than one VAO and VBO might be needed.

import Cocoa
import SceneKit.ModelIO

public class SPMesh {
    var VAO: GLuint = 0
    var VBO: GLuint = 0             // KIV. array of VBOs
    var IBO: GLuint = 0
    var indexCount: GLsizei = 0
    var indexType: GLenum = 0

    init?(_ fileName: String) {
        let myBundle = NSBundle.mainBundle()
        let components = fileName.componentsSeparatedByString(".")
        // The model has 3 vertex attribute: positions, normal & texcoords.
        let assetURL = myBundle.URLForResource(components[0],
                                               withExtension:components[1])
        let asset = MDLAsset(URL: assetURL!)
        //asset.bufferAllocator
        //asset.vertexDescriptor
        //asset[0]
        //asset.boundingBox
        //asset.count
        // properties of MDLMesh
        //let mdlObject = asset[0]!
        //mdlObject.name
        if asset.count != 1 {
            Swift.print("The asset may have multiple instances of MDLMesh")
            return nil
        }
        
        let mdlMesh = asset[0] as! MDLMesh
        let submeshes = mdlMesh.submeshes
        if submeshes.count != 1 {
            Swift.print("The asset has multiple instances of MDLSubmesh")
            return nil
        }

    /*
        mdlMesh.vertexCount
        let descriptor = mdlMesh.vertexDescriptor
        // examine the layouts
        descriptor.layouts.count
        descriptor.layouts[0].stride
        (descriptor.attributes[0] as! MDLVertexAttribute).name
        (descriptor.attributes[0] as! MDLVertexAttribute).offset
        (descriptor.attributes[0] as! MDLVertexAttribute).bufferIndex
        (descriptor.attributes[0] as! MDLVertexAttribute).initializationValue
        
        descriptor.layouts[1].stride
        (descriptor.attributes[1] as! MDLVertexAttribute).name
        (descriptor.attributes[1] as! MDLVertexAttribute).offset
        (descriptor.attributes[1] as! MDLVertexAttribute).bufferIndex
        (descriptor.attributes[1] as! MDLVertexAttribute).initializationValue
        
        descriptor.layouts[2].stride
        (descriptor.attributes[2] as! MDLVertexAttribute).name
        (descriptor.attributes[2] as! MDLVertexAttribute).offset
        (descriptor.attributes[2] as! MDLVertexAttribute).bufferIndex
        (descriptor.attributes[2] as! MDLVertexAttribute).initializationValue
    */
        let smoothingLevel: Float = 0.01
        if mdlMesh.vertexAttributeDataForAttributeNamed(MDLVertexAttributeNormal) == nil {
            mdlMesh.addNormalsWithAttributeNamed(MDLVertexAttributeNormal,
                                                 creaseThreshold:(1.0 - smoothingLevel))
        }
        
        let positionsAttr = mdlMesh.vertexAttributeDataForAttributeNamed(MDLVertexAttributePosition)
        let normalsAttr = mdlMesh.vertexAttributeDataForAttributeNamed(MDLVertexAttributeNormal)
        let uvAttr = mdlMesh.vertexAttributeDataForAttributeNamed(MDLVertexAttributeTextureCoordinate)
        var hasTexCoords = false
        if uvAttr != nil {
            hasTexCoords = true
        }
        var positions = positionsAttr!.dataStart
        var normals = normalsAttr!.dataStart
        var texCoords: UnsafeMutablePointer<Void>!
        if (hasTexCoords) {
            texCoords = uvAttr!.dataStart
        }
 
        // The struct below is 8-byte aligned
        struct Vertex {
            let position: GLKVector3        // 12 bytes
            let normal: GLKVector3          // 12 bytes
            let texCoords: GLKVector2       //  8 bytes
        }
        //sizeof(GLKVector3)
        //sizeof(GLKVector2)
        //sizeof(Vertex)

        // The extracted data will be uploaded to the GPU using OpenGL functions.
        let vertices = UnsafeMutablePointer<Vertex>.alloc(mdlMesh.vertexCount)
        for i in 0..<mdlMesh.vertexCount {
            let position = UnsafeMutablePointer<GLKVector3>(positions).memory
            let normal = UnsafeMutablePointer<GLKVector3>(normals).memory
            var uv = GLKVector2Make(0.0, 0.0)
            if hasTexCoords {
                uv = UnsafeMutablePointer<GLKVector2>(texCoords).memory
            }
            vertices[i] = Vertex(position: position,
                                 normal: normal,
                                 texCoords: uv)
            positions = positions.advancedBy(positionsAttr!.stride)
            normals = normals.advancedBy(normalsAttr!.stride)
            if (hasTexCoords) {
                texCoords = texCoords.advancedBy(uvAttr!.stride)
            }
        }
        
        //mdlMesh.submeshes.count

        // We assume there is only 1 element in the array of MDLSubmeshes.
        let submesh = submeshes[0] as! MDLSubmesh
        //print(submesh.indexBuffer)
        //print(submesh.indexCount)                   // # of indices
        //print(submesh.indexType.rawValue)           // 32=UInt32
        //print(submesh.geometryType.rawValue)        // 2=triangles
        if (submesh.geometryType != MDLGeometryType.TypeTriangles) {
            Swift.print("Mesh data should be composed of triangles")
            return nil
        }
        let indexBuffer = submesh.indexBuffer
        var indexDataSize: GLsizei = 0
        if submesh.indexType == MDLIndexBitDepth.UInt8 {
            indexType = GLenum(GL_UNSIGNED_BYTE)
            indexCount = GLsizei(indexBuffer.length)
            indexDataSize = GLsizei(sizeof(GLubyte))
        }
        else if submesh.indexType == MDLIndexBitDepth.UInt16 {
            indexType = GLenum(GL_UNSIGNED_SHORT)
            indexCount = GLsizei(indexBuffer.length)/2
            indexDataSize = GLsizei(sizeof(GLushort))
        }
        else if submesh.indexType == MDLIndexBitDepth.UInt32 {
            indexType = GLenum(GL_UNSIGNED_INT)
            indexCount = GLsizei(indexBuffer.length)/4
            indexDataSize = GLsizei(sizeof(GLuint))
        }
        else {
            Swift.print("Mesh index type is invalid")
            return nil
        }

        glGenVertexArrays(1, &VAO)
        glBindVertexArray(VAO)
        glGenBuffers(1, &VBO)                         // Create the buffer ID, this is basically the same as generating texture ID's
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), VBO)    // Bind the buffer (vertex array data)
 
        // Upload the vertex data to the GPU
        glBufferData(GLenum(GL_ARRAY_BUFFER),
                     sizeof(Vertex) * mdlMesh.vertexCount,
                     vertices,
                     GLenum(GL_STATIC_DRAW))
        let positionOffset = UnsafePointer<Void>(bitPattern: 0)
        glVertexAttribPointer(0, 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE),
                              GLsizei(sizeof(Vertex)),
                              positionOffset)        // offset
        glEnableVertexAttribArray(0)
        let normalOffset = UnsafePointer<Void>(bitPattern: sizeof(GLfloat)*3)
        glVertexAttribPointer(1, 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE),
                              GLsizei(sizeof(Vertex)),
                              normalOffset)
        glEnableVertexAttribArray(1)
        let uvOffset = UnsafePointer<Void>(bitPattern: sizeof(GLfloat)*6)
        glVertexAttribPointer(2, 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE),
                              GLsizei(sizeof(Vertex)),
                              uvOffset)
        glEnableVertexAttribArray(2)

        glGenBuffers(1, &IBO);
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), IBO)
        // Upload the indices data to the GPU
        glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER),
                     GLsizeiptr(indexDataSize * indexCount),
                     indexBuffer.map().bytes,
                     GLenum(GL_STATIC_DRAW))
        glBindVertexArray(0)
    }

    func render() {
        glBindVertexArray(VAO)
        glEnableVertexAttribArray(0)
        glEnableVertexAttribArray(1)
        glEnableVertexAttribArray(2)
        
        glDrawElements(GLenum(GL_TRIANGLES), indexCount, indexType, nil)
        glBindVertexArray(0)
    }
}
