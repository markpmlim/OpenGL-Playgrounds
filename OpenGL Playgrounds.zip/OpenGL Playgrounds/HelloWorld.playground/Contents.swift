// This is the OpenGL equivalent of Hello, World.

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
