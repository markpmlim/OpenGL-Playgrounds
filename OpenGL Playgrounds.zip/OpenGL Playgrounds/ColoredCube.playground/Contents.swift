// The famous cube with each of the 6 faces shaded
// with a different color.
// An instance of NSTimer is added to support animation. The
// "render:" method of SPOpenGLView will be called repeatedly.

import XCPlayground

// Create instance of ViewController and tell playground
// to show it in live view
let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
