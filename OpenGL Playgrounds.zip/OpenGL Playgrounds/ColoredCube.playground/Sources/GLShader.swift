//
//  GLShader.swift
//
//  Created by Mark Lim Pak Mun on 31/1/15.
//  Copyright (c) 2015 Mark Lim Pak Mun. All rights reserved.
//

/*
 Comments: The shader files are in the Resources subdirectory of the Swift playground.
 The file names are expected to consists of only 2 components, the last
 component being considered the file extension.

 The procedure to compile and link OpenGL shader programs is:
 1) for each shader file, call the method compileShader:shaderType:
	to get a shader ID.
 2)	call the method createAndLinkProgram: to get a program ID using
	the shader IDs obtained from step 1.
*/
import Cocoa
import OpenGL.GL3

// This code can't be moved to an separate source file
// The OpenGL functions were flagged as errors.
public class GLShader
{
    public var program: GLuint = 0

    public init() {
	}
	/*
	Expect the filename of the shader file passed in as a parameter
	consists of exactly 2 components (e.g. vertfrag.vs) and
	is in the Resources subdirectory of the application.
	*/
	public func compileShader(filename: String, shaderType: GLenum) -> GLuint {
		let mainBundle = NSBundle.mainBundle()
		let comps = filename.componentsSeparatedByString(".")
		//print("\(comps)")
		let shaderPath: String? = mainBundle.pathForResource(comps[0], ofType:comps[1])
		if shaderPath == nil {
			print("could not locate the file: \(filename)")
			exit(1)
		}
		//print("shader path:", shaderPath!)
		var shaderID : GLuint = 0
        var source: String?
        do {
            source = try String(contentsOfFile: shaderPath!,
                                encoding: NSUTF8StringEncoding)
        }
        catch _ {
            print("Failed to load shader:", shaderPath)
            return 0
        }

		shaderID = glCreateShader(shaderType)
        // problem - glCreateShader is returning 0! - solved. makeCurrentContext() must be called.
        let contents = source!.cStringUsingEncoding(NSUTF8StringEncoding)	// [CChar]?
        var shaderStringLength = GLint(source!.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        var cStringPtr = UnsafePointer<GLchar>(contents!)
		glShaderSource(shaderID, 1, &cStringPtr, &shaderStringLength)
		glCompileShader(shaderID)

        // But compiling can fail! If we have errors in our GLSL code,  output any errors.
		var compileSuccess: GLint = 0
		glGetShaderiv(shaderID, GLenum(GL_COMPILE_STATUS), &compileSuccess)
		if (compileSuccess == GL_FALSE) {
			var logSize: GLint = 0
			glGetShaderiv(shaderID, GLenum(GL_INFO_LOG_LENGTH), &logSize)
			var infoLog: [GLchar] = [GLchar](count: Int(logSize), repeatedValue: 0)
			var infoLogLength: GLsizei = 0
			glGetShaderInfoLog(shaderID, logSize, &infoLogLength, &infoLog)
            let errMsg = String(UTF8String: infoLog)
            print("Can't compile:", errMsg)
			exit(1)
		}
		return shaderID
	}
	
	// Create and link the shader program using the passed shader IDs
	public func createAndLinkProgram(shaderIDs: [GLuint]) {
		program = glCreateProgram()
		for i in 0..<shaderIDs.count {
			glAttachShader(program, shaderIDs[i])
		}
		glLinkProgram(program)
		// Check for any errors.
		var linkSuccess: GLint = 0
		glGetProgramiv(program, GLenum(GL_LINK_STATUS), &linkSuccess)
		if (linkSuccess == GL_FALSE) {
			var logSize: GLint = 0
			glGetProgramiv (program, GLenum(GL_INFO_LOG_LENGTH), &logSize);
			let infoLog = UnsafeMutablePointer<CChar>.alloc(Int(logSize))
			glGetProgramInfoLog (program, logSize, nil, infoLog);
            let errMsg = String(UTF8String: infoLog)
			print("Failed to create shader program! \(errMsg)")
			exit(1)
		}
		for i in 0 ..< shaderIDs.count {
			//glDetachShader(programID, shaderIDs[i])
			glDeleteShader(shaderIDs[i])
		}
	}

    public func use() {
        glUseProgram(program)
    }
}
