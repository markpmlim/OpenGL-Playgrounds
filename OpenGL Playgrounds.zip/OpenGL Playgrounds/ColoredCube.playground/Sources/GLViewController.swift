
import Cocoa
import OpenGL.GL3
import GLKit

public class SPOpenGLView: NSOpenGLView {
    let shader = GLShader()
    var cubeVAO: GLuint = 0
    var stopClock =  Clock()
    var projectionMatrix = GLKMatrix4Identity
    var modelViewMatrix = GLKMatrix4Identity
    var projectionMatrixLoc: GLint = 0
    var modelViewMatrixLoc: GLint = 0

    public override init?(frame frameRect: NSRect,
                          pixelFormat format: NSOpenGLPixelFormat?) {

        super.init(frame: frameRect, pixelFormat: format)
        let glContext = NSOpenGLContext(format: pixelFormat!,
                                        shareContext: nil)
        self.openGLContext = glContext
        self.openGLContext!.makeCurrentContext()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func prepareOpenGL() {
        super.prepareOpenGL()

        var shaderIDs = [GLuint]()
        var shaderID = shader.compileShader("passthru3D.vs",
                                            shaderType: GLenum(GL_VERTEX_SHADER))
        shaderIDs.append(shaderID)
        shaderID = shader.compileShader("passthru3D.fs",
                                        shaderType: GLenum(GL_FRAGMENT_SHADER))
        shaderIDs.append(shaderID)
        shader.createAndLinkProgram(shaderIDs)
        projectionMatrixLoc = glGetUniformLocation(shader.program, "projectionMatrix");
        modelViewMatrixLoc = glGetUniformLocation(shader.program, "modelViewMatrix");

        createGeometry()
   }

    override public func reshape() {
        super.reshape()
        self.render(stopClock.timeElapsed())
        let width = self.frame.width
        let height = self.frame.height
        let aspectRatio = GLfloat(width)/GLfloat(height)
        projectionMatrix = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(50.0),
                                                     aspectRatio,
                                                     1.0, 100.0)

    }

     override public func drawRect(dirtyRect: NSRect) {
        render(stopClock.timeElapsed())
     }

    // This is called 1/60-th of a second
    func render(elapsedTime: Double) {
        openGLContext!.makeCurrentContext()
        CGLLockContext(openGLContext!.CGLContextObj)
        glClear(GLenum(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT))
        glViewport(0, 0, GLsizei(frame.width), GLsizei(frame.height))

        // Set the background to gray to indicate the render method had been
        // called in case the shaders are not working properly.
        glClearColor(0.5, 0.5, 0.5, 1.0)
        glEnable(GLenum(GL_CULL_FACE))
        glCullFace(GLenum(GL_BACK))
        // Move the camera backwards towards the observer.
        let viewMatrix = GLKMatrix4MakeLookAt(0.0, 0.0, 3.0,
                                              0.0, 0.0, 0.0,
                                              0.0, 1.0, 0.0)

        // Swift cannot handle complex arithmetic expressions
        let f  = GLfloat(elapsedTime)
        let sinx = sin(2.1 * f) * 0.5
        let cosy = cos(1.7 * f) * 0.5
        let sinz = sin(1.3 * f)
        let cosz = cos(1.5 * f)
        // First build the 2 translation matrices
        let trans1Vec = GLKVector3Make(0.0, 0.0, -5.0)
        let trans1Mat = GLKMatrix4TranslateWithVector3(GLKMatrix4Identity, trans1Vec)
        let trans2Vec = GLKVector3Make(sinx, cosy, sinz * cosz * 2.0)
        let trans2Mat = GLKMatrix4TranslateWithVector3(GLKMatrix4Identity, trans2Vec)

        // Next build the rotation matrices
        var aux1Mat = GLKMatrix4RotateX(GLKMatrix4Identity, GLKMathDegreesToRadians(f*81.0))
        let aux2Mat = GLKMatrix4RotateY(GLKMatrix4Identity, GLKMathDegreesToRadians(f*45.0))
        
        // Finally, build the model matrix using translation & rotation matrices
        let auxMat = GLKMatrix4Multiply(aux1Mat, aux2Mat)       // combined rotation matrix
        aux1Mat = GLKMatrix4Multiply(trans1Mat, trans2Mat)      // combined translation matrix
        let modelMatrix = GLKMatrix4Multiply(aux1Mat, auxMat)   // combined to give the model matrix
        modelViewMatrix = GLKMatrix4Multiply(viewMatrix, modelMatrix)
        // Prepare to pass the matrices to the shaders
        let workMatPtr = UnsafeMutablePointer<GLKMatrix4>.alloc(1)
        workMatPtr.memory = projectionMatrix
        let workMat2Ptr = UnsafeMutablePointer<GLKMatrix4>.alloc(1)
        workMat2Ptr.memory = modelViewMatrix
 
        shader.use()
        glBindVertexArray(cubeVAO)
        glUniformMatrix4fv(projectionMatrixLoc, 1, GLboolean(GL_FALSE), UnsafePointer<GLfloat>(workMatPtr))
        glUniformMatrix4fv(modelViewMatrixLoc, 1, GLboolean(GL_FALSE), UnsafePointer<GLfloat>(workMat2Ptr))
        glDrawElements(GLenum(GL_TRIANGLES), 36, GLenum(GL_UNSIGNED_BYTE), nil)
        glBindVertexArray(0)
        glUseProgram(0)
        glDisable(GLenum(GL_CULL_FACE))

        openGLContext!.update()
        // we're double buffered so need to flush to screen
        openGLContext!.flushBuffer()
        CGLUnlockContext(openGLContext!.CGLContextObj)
        workMatPtr.destroy()
        workMat2Ptr.destroy()
    }

    // The rendered object appears to be an open box - solved by culling
    func createGeometry() {
        // total size = 28 bytes; using GLKVectors may not work!
        struct Vertex {
            let position: (GLfloat, GLfloat, GLfloat)       // 12 bytes
            let color: (GLfloat, GLfloat, GLfloat, GLfloat) // 16 bytes
        }

        let vertices: [Vertex] = [
            Vertex(position: (1, 1, -1), color: (1.0, 0.0, 0.0, 1.0)),
            Vertex(position: (-1, 1, -1), color: (1.0, 0.0, 0.0, 1.0)),
            Vertex(position: (-1, 1, 1), color: (1.0, 0.0, 0.0, 1.0)),
            Vertex(position: (1, 1, 1), color: (1.0, 0.0, 0.0, 1.0)),

            Vertex(position: (1, -1, 1), color: (0.0, 1.0, 0.0, 1.0)),
            Vertex(position: (-1, -1, 1), color: (0.0, 1.0, 0.0, 1.0)),
            Vertex(position: (-1, -1, -1), color: (0.0, 1.0, 0.0, 1.0)),
            Vertex(position: (1, -1, -1), color: (0.0, 1.0, 0.0, 1.0)),

            Vertex(position: (1, 1, 1), color: (0.0, 0.0, 1.0, 1.0)),
            Vertex(position: (-1, 1, 1), color: (0.0, 0.0, 1.0, 1.0)),
            Vertex(position: (-1, -1, 1), color: (0.0, 0.0, 1.0, 1.0)),
            Vertex(position: (1, -1,  1), color: (0.0, 0.0, 1.0, 1.0)),

            Vertex(position: (1, -1, -1), color: (1.0, 1.0, 0.0, 1.0)),
            Vertex(position: (-1, -1, -1), color: (1.0, 1.0, 0.0, 1.0)),
            Vertex(position: (-1, 1, -1), color: (1.0, 1.0, 0.0, 1.0)),
            Vertex(position: (1, 1, -1), color: (1.0, 1.0, 0.0, 1.0)),

            Vertex(position: (-1, 1, 1), color: (0.0, 1.0, 1.0, 1.0)),
            Vertex(position: (-1, 1, -1), color: (0.0, 1.0, 1.0, 1.0)),
            Vertex(position: (-1, -1, -1), color: (0.0, 1.0, 1.0, 1.0)),
            Vertex(position: (-1, -1, 1), color: (0.0, 1.0, 1.0, 1.0)),

            Vertex(position: (1, 1, -1), color: (1.0, 0.0, 1.0, 1.0)),
            Vertex(position: (1, 1, 1), color: (1.0, 0.0, 1.0, 1.0)),
            Vertex(position: (1, -1, 1), color: (1.0, 0.0, 1.0, 1.0)),
            Vertex(position: (1, -1, -1), color: (1.0, 0.0, 1.0, 1.0)),
        ]

        let indices: [UInt8] = [
            0,  1,  2,	// triangle 1 &
            2,  3,  0,	//  triangle 2 of top face
            4,  5,  6,
            6,  7,  4,
            8,  9,  10,
            10, 11, 8,
            12, 13, 14,
            14, 15, 12,
            16, 17, 18,
            18, 19, 16,
            20, 21, 22,	// triangle 1 &
            22, 23, 20	//  triangle 2 of right face
        ]

        glGenVertexArrays(1, &cubeVAO)
        glBindVertexArray(cubeVAO)
        var vboId: GLuint = 0
        glGenBuffers(1, &vboId)                         // Create the buffer ID, this is basically the same as generating texture ID's
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), vboId)    // Bind the buffer (vertex array data)

        glBufferData(GLenum(GL_ARRAY_BUFFER),
                     sizeof(Vertex)*vertices.count,
                     vertices, GLenum(GL_STATIC_DRAW))
        let positionAttr = UnsafePointer<Void>(bitPattern: 0)
        glVertexAttribPointer(0,                        // attribute
                              3,                        // size
                              GLenum(GL_FLOAT),         // type
                              GLboolean(GL_FALSE),      // don't normalize
                              GLsizei(sizeof(Vertex)),  // stride
                              positionAttr)             // array buffer offset
        glEnableVertexAttribArray(0)
        let colorAttr = UnsafePointer<Void>(bitPattern: sizeof(Float)*3)
        glVertexAttribPointer(1,
                              4,
                              GLenum(GL_FLOAT),
                              GLboolean(GL_FALSE),
                              GLsizei(sizeof(Vertex)),
                              colorAttr)
        glEnableVertexAttribArray(1)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)

        var eboID: GLuint = 0

        glGenBuffers(1, &eboID)                         // Generate buffer
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER),   // Bind the element array buffer
                     eboID)

        // Upload the index array, this can be done the same way as above (with NULL as the data, then a
        // glBufferSubData call, but doing it all at once for convenience)
        glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER),
                     36 * sizeof(UInt8),
                     indices,
                     GLenum(GL_STATIC_DRAW))
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindVertexArray(0)
   }

    func startTimer() {
        let framesPerSecond = 60
        let timeInterval = 1.0/Double(framesPerSecond)
        NSTimer.scheduledTimerWithTimeInterval(timeInterval,
                                               target: self,
                                               selector: #selector(SPOpenGLView.onTimer(_:)),   //selector: "onTimer:",
                                               userInfo: nil, repeats: true)
    }

    @objc func onTimer(timer: NSTimer!) {
        //Swift.print("Timer here")
        render(stopClock.timeElapsed())
    }
}

public final class SPViewController: NSViewController {

    // This must be implemented
    override public func loadView() {
        //Swift.print("loadView")
        let frameRect = NSRect(x: 0, y: 0,
                               width: 480, height: 270)
        self.view = NSView(frame: frameRect)

        let pixelFormatAttrsBestCase: [NSOpenGLPixelFormatAttribute] = [
            UInt32(NSOpenGLPFADoubleBuffer),
            UInt32(NSOpenGLPFAAccelerated),
            UInt32(NSOpenGLPFABackingStore),
            UInt32(NSOpenGLPFADepthSize), UInt32(24),
            UInt32(NSOpenGLPFAOpenGLProfile), UInt32(NSOpenGLProfileVersion4_1Core),
            UInt32(0)
        ]

        let pf = NSOpenGLPixelFormat(attributes: pixelFormatAttrsBestCase)
        if (pf == nil) {
            fatalError("Couldn't init OpenGL at all, sorry :(")
        }
        let openGLView = SPOpenGLView(frame: frameRect,
                                      pixelFormat: pf)
        self.view.addSubview(openGLView!)
        openGLView!.startTimer()
    }

    override public func viewDidLoad() {
        super.viewDidLoad()
    }
 }

class Clock {
    private static var kNanoSecondConvScale: Double = 1.0e-9
    private var machTimebaseInfoRatio: Double = 0
    private var startTime = 0.0

    init() {
        var timebaseInfo = mach_timebase_info_data_t()
        timebaseInfo.numer = 0
        timebaseInfo.denom = 0
        let err = mach_timebase_info(&timebaseInfo)
        if err != KERN_SUCCESS {
            Swift.print(">> ERROR: \(err) getting mach timebase info!")
        }
        else {
            let numer = Double(timebaseInfo.numer)
            let denom = Double(timebaseInfo.denom)

            // This gives the resolution
            machTimebaseInfoRatio = Clock.kNanoSecondConvScale * (numer/denom)
            startTime = Double(mach_absolute_time())        // in nano seconds
        }
    }

    // Return the elapsed time in seconds
    func timeElapsed() -> Double {
        let currentTime = Double(mach_absolute_time())      // in nano seconds
        let elapsedTime = currentTime - startTime           // in nano seconds
        return elapsedTime * machTimebaseInfoRatio
    }
}
