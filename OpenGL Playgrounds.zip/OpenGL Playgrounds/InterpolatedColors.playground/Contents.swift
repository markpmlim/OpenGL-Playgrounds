// Demonstrates how to use the gl_VertexID variable to set the
// color attribute of a vertex.
// The rasterizer will interpolate the color and sent it to
// the fragment shader.

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
