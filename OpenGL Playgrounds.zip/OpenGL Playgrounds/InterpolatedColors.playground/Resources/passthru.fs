#version 330 core

in vec4 vColor;

out vec4 fragmentColor;

void main(void)
{
    fragmentColor = vColor;
}
