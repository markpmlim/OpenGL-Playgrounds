// This Swift playground shows how to load a image which
// will be used to texture a 2D square.
// Requirements: XCode 7.3.1, macOS 10.11
// It may not work properly on XCode 7.2, macOS 10.10

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
