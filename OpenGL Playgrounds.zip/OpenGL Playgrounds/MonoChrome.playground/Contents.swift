// Swift playground project to demonstrate how to setup
// an OpenGL environment.

import XCPlayground

// Create the instance of ViewController and ...
let vc = SPViewController()
// ... tell playground o show it in a live view
XCPlaygroundPage.currentPage.liveView = vc
