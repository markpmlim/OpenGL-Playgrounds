#version 330 core

out vec4 fragmentColor;

void main(void)
{
	fragmentColor = vec4(0.0, 1.0, 0.0, 1.0);
}
