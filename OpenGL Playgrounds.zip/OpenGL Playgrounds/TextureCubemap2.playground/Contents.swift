// The famous cube with each of the 6 faces textured
// with a different graphic.
// The GLKTextureLoader method cubeMapWithContentsOfURL: considers
// a graphic image whose dimensions are such that its width is 6x its height
// as 6 faces of a cube map.
// If 6 graphic files are used, then the GLKTextureLoader method
//      cubeMapWithContentsOfFiles:options:error:
// must be used.

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
