// An instance of NSTimer is added to support animation. The
// "render:" method of SPOpenGLView will be called repeatedly.
// The shaders are from Apple's SceneKit WWDC 2014 Demo

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
