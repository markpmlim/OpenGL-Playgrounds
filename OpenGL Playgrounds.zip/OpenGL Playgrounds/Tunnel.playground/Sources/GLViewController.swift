
import Cocoa
import OpenGL.GL3
import GLKit

public class SPOpenGLView: NSOpenGLView {
    let shader = GLShader()
    var quadVAO: GLuint = 0
    var stopClock =  Clock()
    var timeLoc: GLint = 0
    var resolutionLoc: GLint = 0
    var factorLoc: GLint = 0
    var fadeFactor: GLfloat = 0
    var fadeFactorDelta: GLfloat = 0

    public override init?(frame frameRect: NSRect,
                          pixelFormat format: NSOpenGLPixelFormat?) {

        super.init(frame: frameRect, pixelFormat: format)
        let glContext = NSOpenGLContext(format: pixelFormat!,
                                        shareContext: nil)
        self.openGLContext = glContext
        self.openGLContext!.makeCurrentContext()
    }

    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func prepareOpenGL() {
        super.prepareOpenGL()

        var shaderIDs = [GLuint]()
        var shaderID = shader.compileShader("tunnel.vs",
                                            shaderType: GLenum(GL_VERTEX_SHADER))
        shaderIDs.append(shaderID)
        shaderID = shader.compileShader("tunnel.fs",
                                        shaderType: GLenum(GL_FRAGMENT_SHADER))
        shaderIDs.append(shaderID)
        shader.createAndLinkProgram(shaderIDs)

        // These uniform locations are referenced by the "render" method.
        // The programmer should checked all returned values are positive integers.
        timeLoc = glGetUniformLocation(shader.program, "time")
        resolutionLoc = glGetUniformLocation(shader.program, "resolution")
        factorLoc = glGetUniformLocation(shader.program, "factor")
        fadeFactor = 0.0
        fadeFactorDelta = 0.05

        createGeometry()
   }

    override public func reshape() {
        super.reshape()
        self.render(stopClock.timeElapsed())
    }

    override public func drawRect(dirtyRect: NSRect) {
        render(stopClock.timeElapsed())
     }

    // This method must be called repeatedly or there won't be animation.
    // An instance of NSTimer will send the "render" message to the instance
    // of SPOpenGLView at 60 frames/second.
    func render(elapsedTime: Double) {
        openGLContext!.makeCurrentContext()
        CGLLockContext(openGLContext!.CGLContextObj)

        glViewport(0, 0, GLsizei(frame.width), GLsizei(frame.height))
        glClear(GLenum(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT))
        glClearColor(0.5, 0.5, 0.5, 1.0)

        glDisable(GLenum(GL_CULL_FACE))
        glDisable(GLenum(GL_DEPTH_TEST))
        shader.use()
        glUniform1f(timeLoc, GLfloat(elapsedTime))
        glUniform1f(factorLoc, fadeFactor)
        // We could have used the frame's width and height.
        var viewPort = [GLint](count: 4, repeatedValue: 0)
        glGetIntegerv(GLenum(GL_VIEWPORT), &viewPort)
        glUniform2f(resolutionLoc,
                    GLfloat(viewPort[2]), GLfloat(viewPort[3]))

        glBindVertexArray(quadVAO)
        glDrawArrays(GLenum(GL_TRIANGLES), 0, 6)
        glBindVertexArray(0)
        glUseProgram(0)
        fadeFactor = max(0, min(1, fadeFactor + fadeFactorDelta))
        glEnable(GLenum(GL_CULL_FACE))
        glEnable(GLenum(GL_DEPTH_TEST))

        openGLContext!.update()
        openGLContext!.flushBuffer()
        CGLUnlockContext(openGLContext!.CGLContextObj)
    }

    func createGeometry() {
        // size = 24 bytes; GLKVectors may not be compatible.
        struct Vertex {
            let position: (GLfloat, GLfloat, GLfloat, GLfloat)  // 16 bytes
            let uv: (GLfloat, GLfloat)                          //  8 bytes
        }

        let vertices: [Vertex] = [
            Vertex(position: (-1.0, 1.0, 0.0, 1.0),   uv: (0.0, 1.0)),
            Vertex(position: (1.0, 1.0, 0.0, 1.0),    uv: (1.0, 1.0)),
            Vertex(position: (-1.0, -1.0, 0.0, 1.0),  uv: (0.0, 0.0)),
            Vertex(position: (-1.0, -1.0, 0.0, 1.0),  uv: (0.0, 0.0)),
            Vertex(position: (1.0, 1.0, 0.0, 1.0),    uv: (1.0, 1.0)),
            Vertex(position: (1.0, -1.0, 0.0, 1.0),   uv: (1.0, 0.0))
        ]

        // The vertex attributes of the quad is embedded in the vertex shader
        // but OpenGL needs to bind a vertex array object (VAO).
        glGenVertexArrays(1, &quadVAO)
        glBindVertexArray(quadVAO)
        var vboId: GLuint = 0
        glGenBuffers(1, &vboId)                         // Create the buffer ID, this is basically the same as generating texture ID's
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), vboId)    // Bind the buffer (vertex array data)

        glBufferData(GLenum(GL_ARRAY_BUFFER),
                     sizeof(Vertex)*vertices.count,
                     vertices, GLenum(GL_STATIC_DRAW))
        let positionAttr = UnsafePointer<Void>(bitPattern: 0)
        glVertexAttribPointer(0,                        // attribute
                              4,                        // size
                              GLenum(GL_FLOAT),         // type
                              GLboolean(GL_FALSE),      // don't normalize
                              GLsizei(sizeof(Vertex)),  // stride
                              positionAttr)             // array buffer offset
        let uvAttr = UnsafePointer<Void>(bitPattern: sizeof(GLfloat)*4)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(1,
                              2,
                              GLenum(GL_FLOAT),
                              GLboolean(GL_FALSE),
                              GLsizei(sizeof(Vertex)),
                              uvAttr)
        glEnableVertexAttribArray(1)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindVertexArray(0)
   }

    // This is required to provide smooth animation
    func startTimer() {
        let framesPerSecond = 60
        let timeInterval = 1.0/Double(framesPerSecond)
        NSTimer.scheduledTimerWithTimeInterval(timeInterval,
                                               target: self,
                                               selector: #selector(SPOpenGLView.onTimer(_:)),   //selector: "onTimer:",
                                               userInfo: nil,
                                               repeats: true)
    }

    // Prepend with "@objc" so that Cocoa's NSTimer will see it.
    @objc func onTimer(timer: NSTimer!) {
        render(stopClock.timeElapsed())
    }
}

public final class SPViewController: NSViewController {

    override public func loadView() {
        let frameRect = NSRect(x: 0, y: 0,
                               width: 480, height: 270)
        self.view = NSView(frame: frameRect)

        let pixelFormatAttrsBestCase: [NSOpenGLPixelFormatAttribute] = [
            UInt32(NSOpenGLPFADoubleBuffer),
            UInt32(NSOpenGLPFAAccelerated),
            UInt32(NSOpenGLPFABackingStore),
            UInt32(NSOpenGLPFADepthSize), UInt32(24),
            UInt32(NSOpenGLPFAOpenGLProfile), UInt32(NSOpenGLProfileVersion4_1Core),
            UInt32(0)
        ]

        let pf = NSOpenGLPixelFormat(attributes: pixelFormatAttrsBestCase)
        if (pf == nil) {
            fatalError("Couldn't init OpenGL at all, sorry :(")
        }
        let openGLView = SPOpenGLView(frame: frameRect,
                                      pixelFormat: pf)
        self.view.addSubview(openGLView!)
        // Remember to start the timer or there will be no animation.
        openGLView!.startTimer()
    }

    override public func viewDidLoad() {
        super.viewDidLoad()
    }
 }

class Clock {
    private static var kNanoSecondConvScale: Double = 1.0e-9
    private var machTimebaseInfoRatio: Double = 0
    private var startTime = 0.0

    init() {
        var timebaseInfo = mach_timebase_info_data_t()
        timebaseInfo.numer = 0
        timebaseInfo.denom = 0
        let err = mach_timebase_info(&timebaseInfo)
        if err != KERN_SUCCESS {
            Swift.print(">> ERROR: \(err) getting mach timebase info!")
        }
        else {
            let numer = Double(timebaseInfo.numer)
            let denom = Double(timebaseInfo.denom)
            
            // This gives the resolution
            machTimebaseInfoRatio = Clock.kNanoSecondConvScale * (numer/denom)
            startTime = Double(mach_absolute_time())        // in nano seconds
        }
    }
    
    // Returns the elapsed time (since the starting time of the program) in seconds
    func timeElapsed() -> Double {
        let currentTime = Double(mach_absolute_time())      // in nano seconds
        let elapsedTime = currentTime - startTime           // in nano seconds
        return elapsedTime * machTimebaseInfoRatio          // in seconds
    }
}
