// This is the OpenGL 4.1 equivalent of Hello, World.

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
