// The famous cube with each of the 6 faces shaded with a different color.
// This is different from the demo "ColoredCube" because a cubemap texture
// is created from scratch.
// https://sites.google.com/site/john87connor/texture-object/tutorial-09-5-cube-map

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
