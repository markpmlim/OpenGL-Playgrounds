// The famous cube with each of the 6 faces textured
// with a different graphic.
// This demo uses the GLKTextureLoader method
//      cubeMapWithContentsOfFiles:options:error:
// to load and instantiate a texture object that could be
// passed to an OpenGL fragment shader.

import XCPlayground

let vc = SPViewController()
XCPlaygroundPage.currentPage.liveView = vc
